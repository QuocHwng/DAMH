﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAMH
{
    public partial class QLTK : Form
    {
        public QLTK()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-S0EAHCL\HUNG2310;Initial Catalog=QuanLyDoiNhom;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
        private void openCon()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
        }

        private void closeCon()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Close();
            }
        }

        private Boolean Exe(string cmd)
        {
            openCon();
            Boolean check;
            try
            {
                SqlCommand sc = new SqlCommand(cmd, con);
                sc.ExecuteNonQuery();
                check = true;
            }
            catch (Exception ex)
            {
                check = false;

            }
            closeCon();
            return check;
        }

        private DataTable Red(string cmd)
        {
            openCon();
            DataTable dt = new DataTable();
            closeCon();
            try
            {
                SqlCommand sc = new SqlCommand(cmd, con);
                SqlDataAdapter adapter = new SqlDataAdapter(sc);
                adapter.Fill(dt);
            }
            catch (Exception)
            {
                dt = null;
                throw;
            }
            return dt;
        }

        private void load()
        {
            DataTable dt = Red("Select * from TaiKhoan");
            if (dt != null)
            {
                dataGridView1.DataSource = dt;
            }
        }
        private void QLTK_Load(object sender, EventArgs e)
        {
            load();
        }
        
        private void button_Them_Click(object sender, EventArgs e)
        {
            Exe("INSERT INTO TaiKhoan(TenDangNhap, MatKhau, Email) VALUES(N'" + textBox_TaiKhoan.Text + "',N'" + textBox_MatKhau.Text + "',N'" + textBox_Email.Text + "')");
            load();
        }
        private void button_Xoa_Click(object sender, EventArgs e)
        {
            Exe("DELETE FROM TaiKhoan WHERE TenDangNhap = '" + textBox_TaiKhoan.Text + "'");
            load();
        }
        private void button_Sua_Click(object sender, EventArgs e)
        {
            Exe("UPDATE TaiKhoan SET MatKhau = N'" + textBox_MatKhau.Text + "',Email = N'" + textBox_Email.Text + "' WHERE TenDangNhap = '" + textBox_TaiKhoan.Text + "' ");
            load();
        }

        private void button_TimKiem_Click_1(object sender, EventArgs e)
        {
            DataTable dt = Red("SELECT * FROM TaiKhoan  WHERE TenDangNhap = '" + textBox_TenTimKiem.Text + "' ");
            if (dt != null)
            {
                dataGridView1.DataSource = dt;
            }
        }
    }
}
