﻿namespace DAMH
{
    partial class Home2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home2));
            panel_Body = new Panel();
            button11 = new Button();
            button10 = new Button();
            button8 = new Button();
            button9 = new Button();
            button_DangXuat = new Button();
            panel_Left = new Panel();
            button6 = new Button();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            button1 = new Button();
            pictureBox1 = new PictureBox();
            panel_Top = new Panel();
            label1 = new Label();
            panel_Body.SuspendLayout();
            panel_Left.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel_Top.SuspendLayout();
            SuspendLayout();
            // 
            // panel_Body
            // 
            panel_Body.Controls.Add(button11);
            panel_Body.Controls.Add(button10);
            panel_Body.Controls.Add(button8);
            panel_Body.Controls.Add(button9);
            panel_Body.Dock = DockStyle.Fill;
            panel_Body.Location = new Point(152, 67);
            panel_Body.Name = "panel_Body";
            panel_Body.Size = new Size(888, 598);
            panel_Body.TabIndex = 7;
            // 
            // button11
            // 
            button11.Location = new Point(488, 329);
            button11.Name = "button11";
            button11.Size = new Size(277, 197);
            button11.TabIndex = 15;
            button11.Text = "Thông báo";
            button11.UseVisualStyleBackColor = true;
            button11.Click += button11_Click;
            // 
            // button10
            // 
            button10.Location = new Point(117, 329);
            button10.Name = "button10";
            button10.Size = new Size(277, 197);
            button10.TabIndex = 14;
            button10.Text = "Người dùng";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // button8
            // 
            button8.Location = new Point(488, 107);
            button8.Name = "button8";
            button8.Size = new Size(277, 197);
            button8.TabIndex = 13;
            button8.Text = "Thành viên nhóm";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.Location = new Point(117, 107);
            button9.Name = "button9";
            button9.Size = new Size(277, 197);
            button9.TabIndex = 12;
            button9.Text = "Đội nhóm";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // button_DangXuat
            // 
            button_DangXuat.Location = new Point(938, 26);
            button_DangXuat.Name = "button_DangXuat";
            button_DangXuat.Size = new Size(75, 23);
            button_DangXuat.TabIndex = 1;
            button_DangXuat.Text = "Đăng xuất";
            button_DangXuat.UseVisualStyleBackColor = true;
            button_DangXuat.Click += button_DangXuat_Click_1;
            // 
            // panel_Left
            // 
            panel_Left.Controls.Add(button6);
            panel_Left.Controls.Add(button5);
            panel_Left.Controls.Add(button4);
            panel_Left.Controls.Add(button3);
            panel_Left.Controls.Add(button1);
            panel_Left.Controls.Add(pictureBox1);
            panel_Left.Dock = DockStyle.Left;
            panel_Left.Location = new Point(0, 67);
            panel_Left.Name = "panel_Left";
            panel_Left.Size = new Size(152, 598);
            panel_Left.TabIndex = 5;
            // 
            // button6
            // 
            button6.Dock = DockStyle.Top;
            button6.Location = new Point(0, 329);
            button6.Name = "button6";
            button6.Size = new Size(152, 58);
            button6.TabIndex = 9;
            button6.Text = "Sinh viên";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button5
            // 
            button5.Dock = DockStyle.Top;
            button5.Location = new Point(0, 271);
            button5.Name = "button5";
            button5.Size = new Size(152, 58);
            button5.TabIndex = 8;
            button5.Text = "Giảng viên";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button4
            // 
            button4.Dock = DockStyle.Top;
            button4.Location = new Point(0, 213);
            button4.Name = "button4";
            button4.Size = new Size(152, 58);
            button4.TabIndex = 7;
            button4.Text = "Môn học";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.Dock = DockStyle.Top;
            button3.Location = new Point(0, 155);
            button3.Name = "button3";
            button3.Size = new Size(152, 58);
            button3.TabIndex = 6;
            button3.Text = "Dự án";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button1
            // 
            button1.Dock = DockStyle.Top;
            button1.Location = new Point(0, 97);
            button1.Name = "button1";
            button1.Size = new Size(152, 58);
            button1.TabIndex = 0;
            button1.Text = "Đội nhóm";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Top;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(152, 97);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // panel_Top
            // 
            panel_Top.Controls.Add(button_DangXuat);
            panel_Top.Controls.Add(label1);
            panel_Top.Dock = DockStyle.Top;
            panel_Top.Location = new Point(0, 0);
            panel_Top.Name = "panel_Top";
            panel_Top.Size = new Size(1040, 67);
            panel_Top.TabIndex = 6;
            panel_Top.Paint += panel_Top_Paint;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Historic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(20, 22);
            label1.Name = "label1";
            label1.Size = new Size(97, 25);
            label1.TabIndex = 2;
            label1.Text = "Trang chủ";
            // 
            // Home2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            ClientSize = new Size(1040, 665);
            Controls.Add(panel_Body);
            Controls.Add(panel_Left);
            Controls.Add(panel_Top);
            Name = "Home2";
            Text = "Home2";
            Load += Home2_Load;
            panel_Body.ResumeLayout(false);
            panel_Left.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel_Top.ResumeLayout(false);
            panel_Top.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel_Body;
        private Button button9;
        private Button button_DangXuat;
        private Panel panel_Left;
        private Button button6;
        private Button button5;
        private Button button4;
        private Button button3;
        private Button button1;
        private PictureBox pictureBox1;
        private Panel panel_Top;
        private Label label1;
        private Button button11;
        private Button button10;
        private Button button8;
    }
}