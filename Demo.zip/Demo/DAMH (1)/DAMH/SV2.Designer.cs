﻿namespace DAMH
{
    partial class SV2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textBox_MaSinhVien = new TextBox();
            label7 = new Label();
            button_Reset = new Button();
            button_Xoa = new Button();
            button_Sua = new Button();
            button_TimKiem = new Button();
            textBox_TenTimKiem = new TextBox();
            label6 = new Label();
            groupBox2 = new GroupBox();
            button_Them = new Button();
            textBox_NganhHoc = new TextBox();
            label2 = new Label();
            groupBox1 = new GroupBox();
            dataGridView1 = new DataGridView();
            groupBox2.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.HotTrack;
            label1.Location = new Point(361, 12);
            label1.Name = "label1";
            label1.Size = new Size(111, 26);
            label1.TabIndex = 12;
            label1.Text = "Sinh Viên";
            // 
            // textBox_MaSinhVien
            // 
            textBox_MaSinhVien.Location = new Point(122, 33);
            textBox_MaSinhVien.Name = "textBox_MaSinhVien";
            textBox_MaSinhVien.Size = new Size(147, 27);
            textBox_MaSinhVien.TabIndex = 17;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Times New Roman", 12F);
            label7.Location = new Point(19, 41);
            label7.Name = "label7";
            label7.Size = new Size(91, 19);
            label7.TabIndex = 16;
            label7.Text = "Mã Sinh Viên";
            // 
            // button_Reset
            // 
            button_Reset.BackColor = Color.LightGray;
            button_Reset.Font = new Font("Times New Roman", 12.75F);
            button_Reset.ForeColor = Color.Black;
            button_Reset.Location = new Point(305, 215);
            button_Reset.Name = "button_Reset";
            button_Reset.Size = new Size(75, 29);
            button_Reset.TabIndex = 15;
            button_Reset.Text = "Reset";
            button_Reset.UseVisualStyleBackColor = false;
            button_Reset.Click += button_Reset_Click_1;
            // 
            // button_Xoa
            // 
            button_Xoa.BackColor = Color.Red;
            button_Xoa.Font = new Font("Times New Roman", 12.75F);
            button_Xoa.ForeColor = Color.Transparent;
            button_Xoa.Location = new Point(305, 159);
            button_Xoa.Name = "button_Xoa";
            button_Xoa.Size = new Size(75, 29);
            button_Xoa.TabIndex = 14;
            button_Xoa.Text = "Xóa";
            button_Xoa.UseVisualStyleBackColor = false;
            button_Xoa.Click += button_Xoa_Click_1;
            // 
            // button_Sua
            // 
            button_Sua.BackColor = Color.DarkOrange;
            button_Sua.Font = new Font("Times New Roman", 12.75F);
            button_Sua.ForeColor = SystemColors.ButtonHighlight;
            button_Sua.Location = new Point(305, 95);
            button_Sua.Name = "button_Sua";
            button_Sua.Size = new Size(75, 29);
            button_Sua.TabIndex = 13;
            button_Sua.Text = "Sửa";
            button_Sua.UseVisualStyleBackColor = false;
            button_Sua.Click += button_Sua_Click_1;
            // 
            // button_TimKiem
            // 
            button_TimKiem.BackColor = Color.LightGray;
            button_TimKiem.Font = new Font("Times New Roman", 12.75F);
            button_TimKiem.ForeColor = Color.Black;
            button_TimKiem.Location = new Point(331, 42);
            button_TimKiem.Name = "button_TimKiem";
            button_TimKiem.Size = new Size(108, 29);
            button_TimKiem.TabIndex = 16;
            button_TimKiem.Text = "Tìm kiếm";
            button_TimKiem.UseVisualStyleBackColor = false;
            button_TimKiem.Click += button_TimKiem_Click_1;
            // 
            // textBox_TenTimKiem
            // 
            textBox_TenTimKiem.Font = new Font("Times New Roman", 12F);
            textBox_TenTimKiem.Location = new Point(122, 45);
            textBox_TenTimKiem.Name = "textBox_TenTimKiem";
            textBox_TenTimKiem.Size = new Size(185, 26);
            textBox_TenTimKiem.TabIndex = 16;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 12F);
            label6.Location = new Point(32, 52);
            label6.Name = "label6";
            label6.Size = new Size(85, 19);
            label6.TabIndex = 15;
            label6.Text = "Mã sinh viên";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(button_TimKiem);
            groupBox2.Controls.Add(textBox_TenTimKiem);
            groupBox2.Controls.Add(label6);
            groupBox2.Font = new Font("Times New Roman", 12.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox2.Location = new Point(3, 81);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(843, 101);
            groupBox2.TabIndex = 15;
            groupBox2.TabStop = false;
            groupBox2.Text = "Tìm kiếm";
            // 
            // button_Them
            // 
            button_Them.BackColor = Color.FromArgb(0, 192, 0);
            button_Them.Font = new Font("Times New Roman", 12.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button_Them.ForeColor = SystemColors.ButtonFace;
            button_Them.Location = new Point(305, 33);
            button_Them.Name = "button_Them";
            button_Them.Size = new Size(75, 29);
            button_Them.TabIndex = 12;
            button_Them.Text = "Thêm ";
            button_Them.UseVisualStyleBackColor = false;
            button_Them.Click += button_Them_Click_1;
            // 
            // textBox_NganhHoc
            // 
            textBox_NganhHoc.Location = new Point(122, 94);
            textBox_NganhHoc.Name = "textBox_NganhHoc";
            textBox_NganhHoc.Size = new Size(147, 27);
            textBox_NganhHoc.TabIndex = 8;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 12F);
            label2.Location = new Point(19, 102);
            label2.Name = "label2";
            label2.Size = new Size(75, 19);
            label2.TabIndex = 4;
            label2.Text = "Ngành học";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBox_MaSinhVien);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(button_Reset);
            groupBox1.Controls.Add(button_Xoa);
            groupBox1.Controls.Add(button_Sua);
            groupBox1.Controls.Add(button_Them);
            groupBox1.Controls.Add(textBox_NganhHoc);
            groupBox1.Controls.Add(label2);
            groupBox1.Font = new Font("Times New Roman", 12.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(3, 188);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(395, 336);
            groupBox1.TabIndex = 14;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thông tin";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(492, 221);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(310, 268);
            dataGridView1.TabIndex = 13;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick_1;
            // 
            // SV2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(848, 537);
            Controls.Add(label1);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(dataGridView1);
            Name = "SV2";
            Text = "SV2";
            Load += SV2_Load;
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBox_MaSinhVien;
        private Label label7;
        private Button button_Reset;
        private Button button_Xoa;
        private Button button_Sua;
        private Button button_TimKiem;
        private TextBox textBox_TenTimKiem;
        private Label label6;
        private GroupBox groupBox2;
        private Button button_Them;
        private TextBox textBox_NganhHoc;
        private Label label2;
        private GroupBox groupBox1;
        private DataGridView dataGridView1;
    }
}