﻿namespace DAMH
{
    partial class Thanhviennhom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox2 = new GroupBox();
            button_TimKiem = new Button();
            textBox_TenTimKiem = new TextBox();
            label6 = new Label();
            groupBox1 = new GroupBox();
            textBox_Id = new TextBox();
            label7 = new Label();
            button_Reset = new Button();
            button_Xoa = new Button();
            button_Sua = new Button();
            button_Them = new Button();
            textBox_VaiTro = new TextBox();
            textBox_MaGiangVien = new TextBox();
            textBox_MaSinhVien = new TextBox();
            textBox_MaDoiNhom = new TextBox();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            dataGridView1 = new DataGridView();
            label1 = new Label();
            groupBox2.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(button_TimKiem);
            groupBox2.Controls.Add(textBox_TenTimKiem);
            groupBox2.Controls.Add(label6);
            groupBox2.Font = new Font("Times New Roman", 12.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox2.Location = new Point(3, 78);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(843, 101);
            groupBox2.TabIndex = 7;
            groupBox2.TabStop = false;
            groupBox2.Text = "Tìm kiếm";
            // 
            // button_TimKiem
            // 
            button_TimKiem.BackColor = Color.LightGray;
            button_TimKiem.Font = new Font("Times New Roman", 12.75F);
            button_TimKiem.ForeColor = Color.Black;
            button_TimKiem.Location = new Point(272, 42);
            button_TimKiem.Name = "button_TimKiem";
            button_TimKiem.Size = new Size(108, 29);
            button_TimKiem.TabIndex = 16;
            button_TimKiem.Text = "Tìm kiếm";
            button_TimKiem.UseVisualStyleBackColor = false;
            button_TimKiem.Click += button_TimKiem_Click_1;
            // 
            // textBox_TenTimKiem
            // 
            textBox_TenTimKiem.Font = new Font("Times New Roman", 12F);
            textBox_TenTimKiem.Location = new Point(63, 45);
            textBox_TenTimKiem.Name = "textBox_TenTimKiem";
            textBox_TenTimKiem.Size = new Size(185, 26);
            textBox_TenTimKiem.TabIndex = 16;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 12F);
            label6.Location = new Point(32, 52);
            label6.Name = "label6";
            label6.Size = new Size(25, 19);
            label6.TabIndex = 15;
            label6.Text = "ID";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBox_Id);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(button_Reset);
            groupBox1.Controls.Add(button_Xoa);
            groupBox1.Controls.Add(button_Sua);
            groupBox1.Controls.Add(button_Them);
            groupBox1.Controls.Add(textBox_VaiTro);
            groupBox1.Controls.Add(textBox_MaGiangVien);
            groupBox1.Controls.Add(textBox_MaSinhVien);
            groupBox1.Controls.Add(textBox_MaDoiNhom);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Font = new Font("Segoe UI", 12.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(3, 185);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(395, 336);
            groupBox1.TabIndex = 6;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thông tin";
            // 
            // textBox_Id
            // 
            textBox_Id.Location = new Point(116, 33);
            textBox_Id.Name = "textBox_Id";
            textBox_Id.Size = new Size(147, 30);
            textBox_Id.TabIndex = 17;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Times New Roman", 12F);
            label7.Location = new Point(13, 41);
            label7.Name = "label7";
            label7.Size = new Size(25, 19);
            label7.TabIndex = 16;
            label7.Text = "ID";
            // 
            // button_Reset
            // 
            button_Reset.BackColor = Color.LightGray;
            button_Reset.Font = new Font("Times New Roman", 12.75F);
            button_Reset.ForeColor = Color.Black;
            button_Reset.Location = new Point(305, 215);
            button_Reset.Name = "button_Reset";
            button_Reset.Size = new Size(75, 29);
            button_Reset.TabIndex = 15;
            button_Reset.Text = "Reset";
            button_Reset.UseVisualStyleBackColor = false;
            button_Reset.Click += button_Reset_Click;
            // 
            // button_Xoa
            // 
            button_Xoa.BackColor = Color.Red;
            button_Xoa.Font = new Font("Times New Roman", 12.75F);
            button_Xoa.ForeColor = Color.Transparent;
            button_Xoa.Location = new Point(305, 159);
            button_Xoa.Name = "button_Xoa";
            button_Xoa.Size = new Size(75, 29);
            button_Xoa.TabIndex = 14;
            button_Xoa.Text = "Xóa";
            button_Xoa.UseVisualStyleBackColor = false;
            button_Xoa.Click += button_Xoa_Click_1;
            // 
            // button_Sua
            // 
            button_Sua.BackColor = Color.DarkOrange;
            button_Sua.Font = new Font("Times New Roman", 12.75F);
            button_Sua.ForeColor = SystemColors.ButtonHighlight;
            button_Sua.Location = new Point(305, 95);
            button_Sua.Name = "button_Sua";
            button_Sua.Size = new Size(75, 29);
            button_Sua.TabIndex = 13;
            button_Sua.Text = "Sửa";
            button_Sua.UseVisualStyleBackColor = false;
            button_Sua.Click += button_Sua_Click_1;
            // 
            // button_Them
            // 
            button_Them.BackColor = Color.FromArgb(0, 192, 0);
            button_Them.Font = new Font("Times New Roman", 12.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button_Them.ForeColor = SystemColors.ButtonFace;
            button_Them.Location = new Point(305, 33);
            button_Them.Name = "button_Them";
            button_Them.Size = new Size(75, 29);
            button_Them.TabIndex = 12;
            button_Them.Text = "Thêm ";
            button_Them.UseVisualStyleBackColor = false;
            button_Them.Click += button_Them_Click_1;
            // 
            // textBox_VaiTro
            // 
            textBox_VaiTro.Location = new Point(116, 275);
            textBox_VaiTro.Name = "textBox_VaiTro";
            textBox_VaiTro.Size = new Size(147, 30);
            textBox_VaiTro.TabIndex = 11;
            // 
            // textBox_MaGiangVien
            // 
            textBox_MaGiangVien.Location = new Point(116, 220);
            textBox_MaGiangVien.Name = "textBox_MaGiangVien";
            textBox_MaGiangVien.Size = new Size(147, 30);
            textBox_MaGiangVien.TabIndex = 10;
            // 
            // textBox_MaSinhVien
            // 
            textBox_MaSinhVien.Location = new Point(116, 156);
            textBox_MaSinhVien.Name = "textBox_MaSinhVien";
            textBox_MaSinhVien.Size = new Size(147, 30);
            textBox_MaSinhVien.TabIndex = 9;
            // 
            // textBox_MaDoiNhom
            // 
            textBox_MaDoiNhom.Location = new Point(116, 94);
            textBox_MaDoiNhom.Name = "textBox_MaDoiNhom";
            textBox_MaDoiNhom.Size = new Size(147, 30);
            textBox_MaDoiNhom.TabIndex = 8;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 12F);
            label5.Location = new Point(12, 283);
            label5.Name = "label5";
            label5.Size = new Size(49, 19);
            label5.TabIndex = 7;
            label5.Text = "Vai trò";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 12F);
            label4.Location = new Point(13, 228);
            label4.Name = "label4";
            label4.Size = new Size(93, 19);
            label4.TabIndex = 6;
            label4.Text = "Mã giảng viên";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 12F);
            label3.Location = new Point(12, 164);
            label3.Name = "label3";
            label3.Size = new Size(85, 19);
            label3.TabIndex = 5;
            label3.Text = "Mã sinh viên";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 12F);
            label2.Location = new Point(13, 102);
            label2.Name = "label2";
            label2.Size = new Size(90, 19);
            label2.TabIndex = 4;
            label2.Text = "Mã đội nhóm";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(425, 208);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(445, 268);
            dataGridView1.TabIndex = 5;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick_1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.HotTrack;
            label1.Location = new Point(343, 16);
            label1.Name = "label1";
            label1.Size = new Size(227, 26);
            label1.TabIndex = 4;
            label1.Text = "Thành viên đội nhóm";
            // 
            // Thanhviennhom
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(912, 537);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(dataGridView1);
            Controls.Add(label1);
            Name = "Thanhviennhom";
            Text = "Thanhviennhom";
            Load += Thanhviennhom_Load;
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox2;
        private Button button_TimKiem;
        private TextBox textBox_TenTimKiem;
        private Label label6;
        private GroupBox groupBox1;
        private TextBox textBox_Id;
        private Label label7;
        private Button button_Reset;
        private Button button_Xoa;
        private Button button_Sua;
        private Button button_Them;
        private TextBox textBox_VaiTro;
        private TextBox textBox_MaGiangVien;
        private TextBox textBox_MaSinhVien;
        private TextBox textBox_MaDoiNhom;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private DataGridView dataGridView1;
        private Label label1;
    }
}