﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAMH
{
    public partial class Kynang : Form
    {
        public Kynang()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-S0EAHCL\HUNG2310;Initial Catalog=QuanLyDoiNhom;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
        private void openCon()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
        }

        private void closeCon()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Close();
            }
        }

        private Boolean Exe(string cmd)
        {
            openCon();
            Boolean check;
            try
            {
                SqlCommand sc = new SqlCommand(cmd, con);
                sc.ExecuteNonQuery();
                check = true;
            }
            catch (Exception ex)
            {
                check = false;

            }
            closeCon();
            return check;
        }

        private DataTable Red(string cmd)
        {
            openCon();
            DataTable dt = new DataTable();
            closeCon();
            try
            {
                SqlCommand sc = new SqlCommand(cmd, con);
                SqlDataAdapter adapter = new SqlDataAdapter(sc);
                adapter.Fill(dt);
            }
            catch (Exception)
            {
                dt = null;
                throw;
            }
            return dt;
        }

        private void load()
        {
            DataTable dt = Red("Select * from KyNang");
            if (dt != null)
            {
                dataGridView1.DataSource = dt;
            }
        }
        private void Kynang_Load(object sender, EventArgs e)
        {
            load();
        }

        private void button_Them_Click(object sender, EventArgs e)
        {
            Exe("INSERT INTO KyNang(MaKyNang, TenKyNang, MoTa) VALUES(N'" + textBox_MaKyNang.Text + "',N'" + textBox_TenKyNang.Text + "',N'" + textBox_MoTa.Text + "')");
            load();
        }

        private void button_Sua_Click(object sender, EventArgs e)
        {
            Exe("UPDATE KyNang SET TenDoiNhom = N'" + textBox_TenKyNang.Text + "',MoTa = N'" + textBox_MoTa.Text + "' WHERE MaKyNang = '" + textBox_MaKyNang.Text + "' ");
            load();
        }

        private void button_Xoa_Click(object sender, EventArgs e)
        {
            Exe("DELETE FROM KyNang WHERE MaKyNang = '" + textBox_MaKyNang.Text + "'");
            load();
        }

        private void button_Reset_Click(object sender, EventArgs e)
        {
            textBox_MoTa.ResetText();
            textBox_TenKyNang.ResetText();
            textBox_MaKyNang.ResetText();
            load();
        }

        private void button_TimKiem_Click(object sender, EventArgs e)
        {
            DataTable dt = Red("SELECT * FROM KyNang  WHERE MaKyNang = '" + textBox_TenTimKiem.Text + "' ");
            if (dt != null)
            {
                dataGridView1.DataSource = dt;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox_MaKyNang.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            textBox_TenKyNang.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            textBox_MoTa.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
        }
    }
}
