﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAMH
{
    class TaiKhoan
    {
        private string tenDangNhap;
        private string matKhau;

        

        public TaiKhoan(string v)
        {
        }

        private bool loaiTaiKhoan;

        public bool LoaiTaiKhoan { get => loaiTaiKhoan; set => loaiTaiKhoan = value; }

        public TaiKhoan(string tenDangNhap, string matKhau)
        {
            this.tenDangNhap = tenDangNhap;
            this.matKhau = matKhau;
            
        }

        public TaiKhoan()
        {
        }

        public string getTenDangNhap()
        {
            return tenDangNhap;
        } 
        public void settenDangNhap(string tenDangNhap)
        {
            this.tenDangNhap= tenDangNhap;
        }

        public string getmatKhau()
        {
            return matKhau;
        }
        public void setmatKhau(string matKhau)
        {
            this.matKhau = matKhau;
        }
    }
}
