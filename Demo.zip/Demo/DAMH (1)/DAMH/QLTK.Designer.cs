﻿namespace DAMH
{
    partial class QLTK
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            textBox_Email = new TextBox();
            groupBox1 = new GroupBox();
            label3 = new Label();
            textBox_TaiKhoan = new TextBox();
            label7 = new Label();
            button_Reset = new Button();
            button_Xoa = new Button();
            button_Sua = new Button();
            button_Them = new Button();
            textBox_MatKhau = new TextBox();
            label2 = new Label();
            button_TimKiem = new Button();
            textBox_TenTimKiem = new TextBox();
            groupBox2 = new GroupBox();
            label6 = new Label();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(492, 221);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(310, 268);
            dataGridView1.TabIndex = 17;
            // 
            // textBox_Email
            // 
            textBox_Email.Location = new Point(122, 159);
            textBox_Email.Name = "textBox_Email";
            textBox_Email.Size = new Size(147, 27);
            textBox_Email.TabIndex = 19;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBox_Email);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(textBox_TaiKhoan);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(button_Reset);
            groupBox1.Controls.Add(button_Xoa);
            groupBox1.Controls.Add(button_Sua);
            groupBox1.Controls.Add(button_Them);
            groupBox1.Controls.Add(textBox_MatKhau);
            groupBox1.Controls.Add(label2);
            groupBox1.Font = new Font("Times New Roman", 12.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(3, 188);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(395, 336);
            groupBox1.TabIndex = 18;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thông tin";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 12F);
            label3.Location = new Point(19, 167);
            label3.Name = "label3";
            label3.Size = new Size(42, 19);
            label3.TabIndex = 18;
            label3.Text = "Email";
            // 
            // textBox_TaiKhoan
            // 
            textBox_TaiKhoan.Location = new Point(122, 33);
            textBox_TaiKhoan.Name = "textBox_TaiKhoan";
            textBox_TaiKhoan.Size = new Size(147, 27);
            textBox_TaiKhoan.TabIndex = 17;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Times New Roman", 12F);
            label7.Location = new Point(19, 41);
            label7.Name = "label7";
            label7.Size = new Size(73, 19);
            label7.TabIndex = 16;
            label7.Text = "Tài Khoản";
            // 
            // button_Reset
            // 
            button_Reset.BackColor = Color.LightGray;
            button_Reset.Font = new Font("Times New Roman", 12.75F);
            button_Reset.ForeColor = Color.Black;
            button_Reset.Location = new Point(305, 215);
            button_Reset.Name = "button_Reset";
            button_Reset.Size = new Size(75, 29);
            button_Reset.TabIndex = 15;
            button_Reset.Text = "Reset";
            button_Reset.UseVisualStyleBackColor = false;
            // 
            // button_Xoa
            // 
            button_Xoa.BackColor = Color.Red;
            button_Xoa.Font = new Font("Times New Roman", 12.75F);
            button_Xoa.ForeColor = Color.Transparent;
            button_Xoa.Location = new Point(305, 159);
            button_Xoa.Name = "button_Xoa";
            button_Xoa.Size = new Size(75, 29);
            button_Xoa.TabIndex = 14;
            button_Xoa.Text = "Xóa";
            button_Xoa.UseVisualStyleBackColor = false;
            // 
            // button_Sua
            // 
            button_Sua.BackColor = Color.DarkOrange;
            button_Sua.Font = new Font("Times New Roman", 12.75F);
            button_Sua.ForeColor = SystemColors.ButtonHighlight;
            button_Sua.Location = new Point(305, 95);
            button_Sua.Name = "button_Sua";
            button_Sua.Size = new Size(75, 29);
            button_Sua.TabIndex = 13;
            button_Sua.Text = "Sửa";
            button_Sua.UseVisualStyleBackColor = false;
            // 
            // button_Them
            // 
            button_Them.BackColor = Color.FromArgb(0, 192, 0);
            button_Them.Font = new Font("Times New Roman", 12.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button_Them.ForeColor = SystemColors.ButtonFace;
            button_Them.Location = new Point(305, 33);
            button_Them.Name = "button_Them";
            button_Them.Size = new Size(75, 29);
            button_Them.TabIndex = 12;
            button_Them.Text = "Thêm ";
            button_Them.UseVisualStyleBackColor = false;
            // 
            // textBox_MatKhau
            // 
            textBox_MatKhau.Location = new Point(122, 94);
            textBox_MatKhau.Name = "textBox_MatKhau";
            textBox_MatKhau.Size = new Size(147, 27);
            textBox_MatKhau.TabIndex = 8;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 12F);
            label2.Location = new Point(19, 102);
            label2.Name = "label2";
            label2.Size = new Size(67, 19);
            label2.TabIndex = 4;
            label2.Text = "Mật khẩu";
            // 
            // button_TimKiem
            // 
            button_TimKiem.BackColor = Color.LightGray;
            button_TimKiem.Font = new Font("Times New Roman", 12.75F);
            button_TimKiem.ForeColor = Color.Black;
            button_TimKiem.Location = new Point(331, 42);
            button_TimKiem.Name = "button_TimKiem";
            button_TimKiem.Size = new Size(108, 29);
            button_TimKiem.TabIndex = 16;
            button_TimKiem.Text = "Tìm kiếm";
            button_TimKiem.UseVisualStyleBackColor = false;
            button_TimKiem.Click += button_TimKiem_Click_1;
            // 
            // textBox_TenTimKiem
            // 
            textBox_TenTimKiem.Font = new Font("Times New Roman", 12F);
            textBox_TenTimKiem.Location = new Point(122, 45);
            textBox_TenTimKiem.Name = "textBox_TenTimKiem";
            textBox_TenTimKiem.Size = new Size(185, 26);
            textBox_TenTimKiem.TabIndex = 16;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(button_TimKiem);
            groupBox2.Controls.Add(textBox_TenTimKiem);
            groupBox2.Controls.Add(label6);
            groupBox2.Font = new Font("Times New Roman", 12.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox2.Location = new Point(3, 81);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(843, 101);
            groupBox2.TabIndex = 19;
            groupBox2.TabStop = false;
            groupBox2.Text = "Tìm kiếm";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 12F);
            label6.Location = new Point(32, 52);
            label6.Name = "label6";
            label6.Size = new Size(69, 19);
            label6.TabIndex = 15;
            label6.Text = "Tài khoản";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.HotTrack;
            label1.Location = new Point(361, 12);
            label1.Name = "label1";
            label1.Size = new Size(115, 26);
            label1.TabIndex = 16;
            label1.Text = "Tài khoản";
            // 
            // QLTK
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(848, 537);
            Controls.Add(dataGridView1);
            Controls.Add(groupBox1);
            Controls.Add(groupBox2);
            Controls.Add(label1);
            Name = "QLTK";
            Text = "QLTK";
            Load += QLTK_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private TextBox textBox_Email;
        private GroupBox groupBox1;
        private Label label3;
        private TextBox textBox_TaiKhoan;
        private Label label7;
        private Button button_Reset;
        private Button button_Xoa;
        private Button button_Sua;
        private Button button_Them;
        private TextBox textBox_MatKhau;
        private Label label2;
        private Button button_TimKiem;
        private TextBox textBox_TenTimKiem;
        private GroupBox groupBox2;
        private Label label6;
        private Label label1;
    }
}