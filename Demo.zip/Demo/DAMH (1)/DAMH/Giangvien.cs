﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAMH
{
    public partial class Giangvien : Form
    {
        public Giangvien()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-S0EAHCL\HUNG2310;Initial Catalog=QuanLyDoiNhom;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
        private void openCon()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
        }

        private void closeCon()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Close();
            }
        }

        private Boolean Exe(string cmd)
        {
            openCon();
            Boolean check;
            try
            {
                SqlCommand sc = new SqlCommand(cmd, con);
                sc.ExecuteNonQuery();
                check = true;
            }
            catch (Exception ex)
            {
                check = false;

            }
            closeCon();
            return check;
        }

        private DataTable Red(string cmd)
        {
            openCon();
            DataTable dt = new DataTable();
            closeCon();
            try
            {
                SqlCommand sc = new SqlCommand(cmd, con);
                SqlDataAdapter adapter = new SqlDataAdapter(sc);
                adapter.Fill(dt);
            }
            catch (Exception)
            {
                dt = null;
                throw;
            }
            return dt;
        }

        private void load()
        {
            DataTable dt = Red("Select * from GiangVien");
            if (dt != null)
            {
                dataGridView1.DataSource = dt;
            }
        }
        private void Giangvien_Load(object sender, EventArgs e)
        {
            load();
        }

        private void button_Them_Click(object sender, EventArgs e)
        {
            Exe("INSERT INTO GiangVien(MaGiangVien, Khoa) VALUES (N'" + textBox_MaGiangVien.Text + "',N'" + textBox_Khoa.Text + "')");
            load();
        }

        private void button_Sua_Click(object sender, EventArgs e)
        {
            Exe("UPDATE GiangVien SET Khoa = N'" + textBox_Khoa.Text + "' WHERE MaSinhVien= '" + textBox_MaGiangVien.Text + "' ");
            load();
        }

        private void button_Xoa_Click(object sender, EventArgs e)
        {
            Exe("DELETE FROM GiangVien WHERE MaGiangVien = '" + textBox_MaGiangVien.Text + "'");
            load();
        }

        private void button_Reset_Click(object sender, EventArgs e)
        {
            textBox_MaGiangVien.ResetText();
            textBox_Khoa.ResetText();
            load();
        }

        private void button_TimKiem_Click(object sender, EventArgs e)
        {
            DataTable dt = Red("SELECT * FROM GiangVien  WHERE MaGiangVien = '" + textBox_TenTimKiem.Text + "' ");
            if (dt != null)
            {
                dataGridView1.DataSource = dt;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox_MaGiangVien.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            textBox_Khoa.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
        }
    }
}
