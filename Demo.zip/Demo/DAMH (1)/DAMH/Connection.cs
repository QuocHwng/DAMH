﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Microsoft.Data.SqlClient;

namespace DAMH
{
    public class Connection
    {
        // Biến connection string nên là static để dùng chung
        private static string stringConnection = @"Data Source=DESKTOP-S0EAHCL\HUNG2310;Initial Catalog=QuanLyDoiNhom;Integrated Security=True;Encrypt=True;Trust Server Certificate=True";


        public static SqlConnection GetSqlConnection()
        {
            // Tạo một SqlConnection MỚI bên trong phương thức
            return new SqlConnection(stringConnection);  // Dùng stringConnection static
        }

        // Ví dụ sử dụng (luôn đặt trong khối using)
        public static void SomeDatabaseOperation()
        {
            using (SqlConnection connection = GetSqlConnection())
            {
                try
                {
                    connection.Open();
                    // ... Các thao tác với database ...
                }
                catch (SqlException ex)
                {
                    // Xử lý ngoại lệ (log, hiển thị thông báo, v.v.)
                    Console.WriteLine("Lỗi database: " + ex.Message);
                }
            } // Kết nối tự động đóng và giải phóng ở đây
        }
    }
}