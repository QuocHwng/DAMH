﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAMH
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }
        private Form currentFormChild;


        private void OpenChildForm(Form childForm)
        {
            if (currentFormChild != null)
            {
                currentFormChild.Close();
            }
            currentFormChild = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panel_Body.Controls.Add(childForm);
            panel_Body.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();

        }
        private void button_DangXuat_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn đăng xuất không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult) ;
            {
                this.Hide();
                Dangnhap dangnhap = new Dangnhap();
                dangnhap.ShowDialog();
            }
        }

        private void Home_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Doinhom());
            label1.Text = button1.Text;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Thanhviennhom());
            label1.Text = button2.Text;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Duan());
            label1.Text = button3.Text;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Monhoc());
            label1.Text = button4.Text;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Giangvien());
            label1.Text = button5.Text;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Sinhvien());
            label1.Text = button6.Text;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (currentFormChild != null)
            {
                currentFormChild.Close();

            }
            label1.Text = "Trang chủ";
        }

        private void panel_Body_Paint(object sender, PaintEventArgs e)
        {

        }



        private void button7_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Thongbao());
            label1.Text = button7.Text;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Kynang());
            label1.Text = button8.Text;
        }

        private void button9_Click(object sender, EventArgs e)
        {


            OpenChildForm(new QLTK());
            label1.Text = button9.Text;
        }
    }
}
