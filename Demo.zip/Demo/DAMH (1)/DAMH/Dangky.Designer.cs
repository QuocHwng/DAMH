﻿namespace DAMH
{
    partial class Dangky
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dangky));
            button_DangKy = new Button();
            textBox_MatKhau = new TextBox();
            label2 = new Label();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            textBox_TenDangNhap = new TextBox();
            label3 = new Label();
            textBox_XNMatKhau = new TextBox();
            label4 = new Label();
            textBox_Email = new TextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // button_DangKy
            // 
            button_DangKy.Location = new Point(239, 305);
            button_DangKy.Name = "button_DangKy";
            button_DangKy.Size = new Size(75, 23);
            button_DangKy.TabIndex = 16;
            button_DangKy.Text = "Đăng ký";
            button_DangKy.UseVisualStyleBackColor = true;
            button_DangKy.Click += button_DangKy_Click;
            // 
            // textBox_MatKhau
            // 
            textBox_MatKhau.Location = new Point(186, 195);
            textBox_MatKhau.Name = "textBox_MatKhau";
            textBox_MatKhau.PasswordChar = '*';
            textBox_MatKhau.Size = new Size(128, 23);
            textBox_MatKhau.TabIndex = 15;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(42, 203);
            label2.Name = "label2";
            label2.Size = new Size(57, 15);
            label2.TabIndex = 13;
            label2.Text = "Mật khẩu";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(85, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(180, 114);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 12;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(42, 169);
            label1.Name = "label1";
            label1.Size = new Size(57, 15);
            label1.TabIndex = 10;
            label1.Text = "Tài khoản";
            // 
            // textBox_TenDangNhap
            // 
            textBox_TenDangNhap.Location = new Point(186, 166);
            textBox_TenDangNhap.Name = "textBox_TenDangNhap";
            textBox_TenDangNhap.Size = new Size(128, 23);
            textBox_TenDangNhap.TabIndex = 9;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(42, 230);
            label3.Name = "label3";
            label3.Size = new Size(124, 15);
            label3.TabIndex = 18;
            label3.Text = "Xác nhận lại mật khẩu";
            label3.Click += label3_Click;
            // 
            // textBox_XNMatKhau
            // 
            textBox_XNMatKhau.Location = new Point(186, 227);
            textBox_XNMatKhau.Name = "textBox_XNMatKhau";
            textBox_XNMatKhau.PasswordChar = '*';
            textBox_XNMatKhau.Size = new Size(128, 23);
            textBox_XNMatKhau.TabIndex = 17;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(42, 259);
            label4.Name = "label4";
            label4.Size = new Size(36, 15);
            label4.TabIndex = 20;
            label4.Text = "Email";
            // 
            // textBox_Email
            // 
            textBox_Email.Location = new Point(186, 256);
            textBox_Email.Name = "textBox_Email";
            textBox_Email.Size = new Size(128, 23);
            textBox_Email.TabIndex = 19;
            // 
            // Dangky
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(357, 384);
            Controls.Add(label4);
            Controls.Add(textBox_Email);
            Controls.Add(label3);
            Controls.Add(textBox_XNMatKhau);
            Controls.Add(button_DangKy);
            Controls.Add(textBox_MatKhau);
            Controls.Add(label2);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Controls.Add(textBox_TenDangNhap);
            Name = "Dangky";
            Text = "Dangky";
            Load += Dangky_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button_DangKy;
        private TextBox textBox_MatKhau;
        private Label label2;
        private PictureBox pictureBox1;
        private Label label1;
        private TextBox textBox_TenDangNhap;
        private Label label3;
        private TextBox textBox_XNMatKhau;
        private Label label4;
        private TextBox textBox_Email;
    }
}