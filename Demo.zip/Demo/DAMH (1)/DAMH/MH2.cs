﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAMH
{
    public partial class MH2 : Form
    {
        public MH2()
        {
            InitializeComponent();
        }

        private void MH2_Load(object sender, EventArgs e)
        {
            load();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-S0EAHCL\HUNG2310;Initial Catalog=QuanLyDoiNhom;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
        private void openCon()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
        }

        private void closeCon()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Close();
            }
        }

        private Boolean Exe(string cmd)
        {
            openCon();
            Boolean check;
            try
            {
                SqlCommand sc = new SqlCommand(cmd, con);
                sc.ExecuteNonQuery();
                check = true;
            }
            catch (Exception ex)
            {
                check = false;

            }
            closeCon();
            return check;
        }

        private DataTable Red(string cmd)
        {
            openCon();
            DataTable dt = new DataTable();
            closeCon();
            try
            {
                SqlCommand sc = new SqlCommand(cmd, con);
                SqlDataAdapter adapter = new SqlDataAdapter(sc);
                adapter.Fill(dt);
            }
            catch (Exception)
            {
                dt = null;
                throw;
            }
            return dt;
        }

        private void load()
        {
            DataTable dt = Red("Select * from MonHoc");
            if (dt != null)
            {
                dataGridView1.DataSource = dt;
            }
        }
        private void Monhoc_Load(object sender, EventArgs e)
        {
            load();
        }

        
        

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox_MaMonHoc.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            textBox_TenMonHoc.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();

        }

        private void button_TimKiem_Click(object sender, EventArgs e)
        {
            
        }

        private void button_Them_Click_1(object sender, EventArgs e)
        {
            Exe("INSERT INTO MonHoc(MaMonHoc, TenMonHoc) VALUES(N'" + textBox_MaMonHoc.Text + "',N'" + textBox_TenMonHoc.Text + "')");
            load();
        }

        private void button_Sua_Click_1(object sender, EventArgs e)
        {
            Exe("UPDATE MonHoc SET TenMonHoc = N'" + textBox_TenMonHoc.Text + "' WHERE MaMonHoc = '" + textBox_MaMonHoc.Text + "' ");
            load();
        }

        private void button_Xoa_Click_1(object sender, EventArgs e)
        {
            Exe("DELETE FROM MonHoc WHERE MaMonHoc = '" + textBox_MaMonHoc.Text + "'");
            load();
        }

        private void button_Reset_Click_1(object sender, EventArgs e)
        {
            textBox_MaMonHoc.ResetText();
            textBox_TenMonHoc.ResetText();
            load();
        }

        private void button_TimKiem_Click_1(object sender, EventArgs e)
        {
            DataTable dt = Red("SELECT * FROM MonHoc  WHERE MaMonHoc = '" + textBox_TenTimKiem.Text + "' ");
            if (dt != null)
            {
                dataGridView1.DataSource = dt;
            }
        }
    }
}
