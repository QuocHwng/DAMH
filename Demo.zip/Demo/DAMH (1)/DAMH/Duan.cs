﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAMH
{
    public partial class Duan : Form
    {
        public Duan()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox_TenTimKiem_TextChanged(object sender, EventArgs e)
        {

        }

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-S0EAHCL\HUNG2310;Initial Catalog=QuanLyDoiNhom;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
        private void openCon()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
        }

        private void closeCon()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Close();
            }
        }

        private Boolean Exe(string cmd)
        {
            openCon();
            Boolean check;
            try
            {
                SqlCommand sc = new SqlCommand(cmd, con);
                sc.ExecuteNonQuery();
                check = true;
            }
            catch (Exception ex)
            {
                check = false;

            }
            closeCon();
            return check;
        }

        private DataTable Red(string cmd)
        {
            openCon();
            DataTable dt = new DataTable();
            closeCon();
            try
            {
                SqlCommand sc = new SqlCommand(cmd, con);
                SqlDataAdapter adapter = new SqlDataAdapter(sc);
                adapter.Fill(dt);
            }
            catch (Exception)
            {
                dt = null;
                throw;
            }
            return dt;
        }

        private void load()
        {
            DataTable dt = Red("Select * from DuAn");
            if (dt != null)
            {
                dataGridView1.DataSource = dt;
            }
        }

        private void button_TimKiem_Click(object sender, EventArgs e)
        {
            DataTable dt = Red("SELECT * FROM DuAn  WHERE MaDuAn = '" + textBox_TenTimKiem.Text + "' ");
            if (dt != null)
            {
                dataGridView1.DataSource = dt;
            }
        }

        private void button_Them_Click(object sender, EventArgs e)
        {

            Exe("INSERT INTO DuAn(MaDuAn, TenDuAn, MoTa, NgayBatDau,NgayKetThuc, TrangThaiDuAn) VALUES(N'" + textBox_MaDuAn.Text + "',N'" + textBox_TenDuAn.Text + "',N'" + textBox_MoTa.Text + "',N'" + textBox_NgayBatDau.Text + "','" + textBox_NgayKetThuc.Text + "', N'" + textBox_TrangThai.Text + "')");
            load();
        }

        private void button_Sua_Click(object sender, EventArgs e)
        {
            Exe("UPDATE DuAn SET TenDuAn = N'" + textBox_TenDuAn.Text + "', MoTa = N'" + textBox_MoTa.Text + "',NgayBatDau =N'" + textBox_NgayBatDau.Text + "',NgayKetThuc =N'" + textBox_NgayKetThuc.Text + "' ,TrangThai = N'" + textBox_TrangThai.Text + "' WHERE MaDuAn = '" + textBox_MaDuAn.Text + "' ");
            load();
        }

        private void button_Xoa_Click(object sender, EventArgs e)
        {
            Exe("DELETE FROM DuAn WHERE MaDuAn = '" + textBox_MaDuAn.Text + "'");
            load();
        }

        private void button_Reset_Click(object sender, EventArgs e)
        {
            textBox_MaDuAn.ResetText();
            textBox_MoTa.ResetText();
            textBox_TenDuAn.ResetText();
            textBox_NgayBatDau.ResetText();
            textBox_NgayKetThuc.ResetText();
            textBox_TrangThai.ResetText();
            load();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox_MaDuAn.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            textBox_TenDuAn.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            textBox_MoTa.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            textBox_NgayBatDau.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            textBox_NgayKetThuc.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            textBox_TrangThai.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
        }

        private void Duan_Load(object sender, EventArgs e)
        {
            load();
        }
    }
}
