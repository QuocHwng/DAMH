﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAMH
{
    public partial class Thongbao : Form
    {
        public Thongbao()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-S0EAHCL\HUNG2310;Initial Catalog=QuanLyDoiNhom;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");
        private void openCon()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
        }

        private void closeCon()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Close();
            }
        }

        private Boolean Exe(string cmd)
        {
            openCon();
            Boolean check;
            try
            {
                SqlCommand sc = new SqlCommand(cmd, con);
                sc.ExecuteNonQuery();
                check = true;
            }
            catch (Exception ex)
            {
                check = false;

            }
            closeCon();
            return check;
        }

        private DataTable Red(string cmd)
        {
            openCon();
            DataTable dt = new DataTable();
            closeCon();
            try
            {
                SqlCommand sc = new SqlCommand(cmd, con);
                SqlDataAdapter adapter = new SqlDataAdapter(sc);
                adapter.Fill(dt);
            }
            catch (Exception)
            {
                dt = null;
                throw;
            }
            return dt;
        }

        private void load()
        {
            DataTable dt = Red("Select * from ThongBao");
            if (dt != null)
            {
                dataGridView1.DataSource = dt;
            }
        }
        private void Thongbao_Load(object sender, EventArgs e)
        {
            load();
        }

        

        private void button_Them_Click_1(object sender, EventArgs e)
        {
            try
            {
                // 1. Tạo MaThongBao (Khóa chính - Sử dụng GUID)
                Guid maThongBao = Guid.NewGuid();

                string query = "INSERT INTO ThongBao(MaThongBao, NoiDung, ThoiGian, DaXem, MaNguoiNhan) " +
                               "VALUES(@MaThongBao, @NoiDung, @ThoiGian, @DaXem, @MaNguoiNhan)";

                using (SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-6MLH8QH\HUNG;Initial Catalog = QuanLyDuAn; Integrated Security = True; Trust Server Certificate=True")) // Thay connectionString bằng chuỗi kết nối của bạn
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@MaThongBao", maThongBao);
                    cmd.Parameters.AddWithValue("@NoiDung", textBox_NoiDung.Text);
                    cmd.Parameters.AddWithValue("@ThoiGian", DateTime.Now); // Hoặc lấy từ textbox_ThoiGian nếu có
                    cmd.Parameters.AddWithValue("@DaXem", false); // Hoặc lấy giá trị từ checkbox nếu có


                    // 2. MaNguoiNhan là string
                    string maNguoiNhan = textBox_MaNguoiNhan.Text;

                    // 3. Kiểm tra MaNguoiNhan (Khóa ngoại) - vẫn cần kiểm tra tồn tại
                    string checkQuery = "SELECT COUNT(*) FROM NguoiNhan WHERE MaNguoiNhan = @MaNguoiNhan";
                    using (SqlCommand checkCmd = new SqlCommand(checkQuery, connection))
                    {
                        checkCmd.Parameters.AddWithValue("@MaNguoiNhan", maNguoiNhan);
                        connection.Open();
                        int count = (int)checkCmd.ExecuteScalar();
                        if (count == 0)
                        {
                            MessageBox.Show("Mã người nhận không tồn tại.");
                            return;
                        }
                    }

                    cmd.Parameters.AddWithValue("@MaNguoiNhan", maNguoiNhan);

                    cmd.ExecuteNonQuery();
                    load();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void button_Sua_Click_1(object sender, EventArgs e)
        {
            Exe("UPDATE ThongBao SET NoiDung = N'" + textBox_NoiDung.Text + "',ThoiGian = N'" + textBox_ThoiGian.Text + "',DaXem = N'" + textBox_DaXem + "', MaNguoiNhan = '"+textBox_MaNguoiNhan+"' WHERE MaThongBao = '" + textBox_MaThongBao.Text + "' ");
            load();
        }

        private void button_Xoa_Click_1(object sender, EventArgs e)
        {
            Exe("DELETE FROM ThongBao WHERE MaThongBao = '" + textBox_MaThongBao.Text + "'");
            load();
        }

        private void button_Reset_Click_1(object sender, EventArgs e)
        {
            textBox_ThoiGian.ResetText();
            textBox_NoiDung.ResetText();
            textBox_MaThongBao.ResetText();
            textBox_DaXem.ResetText();
            textBox_MaNguoiNhan.ResetText();
            load();
        }

        private void button_TimKiem_Click_1(object sender, EventArgs e)
        {
            DataTable dt = Red("SELECT * FROM ThongBao  WHERE MaThongBao = '" + textBox_TenTimKiem.Text + "' ");
            if (dt != null)
            {
                dataGridView1.DataSource = dt;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox_MaThongBao.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            textBox_NoiDung.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            textBox_ThoiGian.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            textBox_DaXem.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            textBox_MaNguoiNhan.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
        }
    }
}
