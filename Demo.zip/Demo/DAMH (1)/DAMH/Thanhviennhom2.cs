﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAMH
{
    public partial class Thanhviennhom2 : Form
    {
        public Thanhviennhom2()
        {
            InitializeComponent();
        }

        private void Thanhviennhom2_Load(object sender, EventArgs e)
        {
            load();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-S0EAHCL\HUNG2310;Initial Catalog=QuanLyDoiNhom;Integrated Security=True;Encrypt=True");
        private void openCon()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
        }

        private void closeCon()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Close();
            }
        }

        private Boolean Exe(string cmd)
        {
            openCon();
            Boolean check;
            try
            {
                SqlCommand sc = new SqlCommand(cmd, con);
                sc.ExecuteNonQuery();
                check = true;
            }
            catch (Exception ex)
            {
                check = false;

            }
            closeCon();
            return check;
        }

        private DataTable Red(string cmd)
        {
            openCon();
            DataTable dt = new DataTable();
            closeCon();
            try
            {
                SqlCommand sc = new SqlCommand(cmd, con);
                SqlDataAdapter adapter = new SqlDataAdapter(sc);
                adapter.Fill(dt);
            }
            catch (Exception)
            {
                dt = null;
                throw;
            }
            return dt;
        }

        private void load()
        {
            DataTable dt = Red("Select * from ThanhVienDoiNhom");
            if (dt != null)
            {
                dataGridView1.DataSource = dt;
            }
        }
        private void Thanhviennhom_Load(object sender, EventArgs e)
        {
            load();
        }




        private void button_Them_Click_1(object sender, EventArgs e)
        {
            try
            {

                string sql = "INSERT INTO ThanhVienDoiNhom (MaDoiNhom, MaSinhVien, MaGiangVien, VaiTro) VALUES (@MaDoiNhom, @MaSinhVien, @MaGiangVien, @VaiTro)";

                using (SqlCommand command = new SqlCommand(sql, con))
                {
                    command.Parameters.AddWithValue("@MaDoiNhom", textBox_MaDoiNhom.Text);

                    // Xử lý NULL cho MaSinhVien và MaGiangVien
                    if (string.IsNullOrEmpty(textBox_MaSinhVien.Text))
                    {
                        command.Parameters.AddWithValue("@MaSinhVien", DBNull.Value);
                    }
                    else
                    {
                        command.Parameters.AddWithValue("@MaSinhVien", textBox_MaSinhVien.Text);
                    }

                    if (string.IsNullOrEmpty(textBox_MaGiangVien.Text))
                    {
                        command.Parameters.AddWithValue("@MaGiangVien", DBNull.Value);
                    }
                    else
                    {
                        command.Parameters.AddWithValue("@MaGiangVien", textBox_MaGiangVien.Text);
                    }


                    command.Parameters.AddWithValue("@VaiTro", textBox_VaiTro.Text);


                    command.ExecuteNonQuery();

                }


                load();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }

        }
        public void Exec(SqlCommand command)
        {
            using (SqlConnection connection = Connection.GetSqlConnection())
            {
                try
                {
                    connection.Open();
                    command.Connection = connection; // Gán kết nối cho command
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    // Xử lý lỗi
                    MessageBox.Show("Lỗi trong Exec: " + ex.Message);
                }
            }
        }

        private void button_Sua_Click_1(object sender, EventArgs e)
        {
            try
            {


                // Xây dựng câu lệnh UPDATE
                string sql = "UPDATE ThanhVienDoiNhom SET ";

                // Thêm các trường cần cập nhật
                if (!string.IsNullOrEmpty(textBox_VaiTro.Text))
                {
                    sql += "VaiTro = @VaiTro,";
                }

                // Xử lý MaSinhVien và MaGiangVien (chỉ một trong hai được phép có giá trị)
                if (!string.IsNullOrEmpty(textBox_MaSinhVien.Text))
                {
                    sql += "MaSinhVien = @MaSinhVien, MaGiangVien = NULL,";  // Cập nhật MaSinhVien và đặt MaGiangVien là NULL
                }
                else if (!string.IsNullOrEmpty(textBox_MaGiangVien.Text))
                {
                    sql += "MaGiangVien = @MaGiangVien, MaSinhVien = NULL,"; // Cập nhật MaGiangVien và đặt MaSinhVien là NULL
                }


                // Loại bỏ dấu phẩy cuối cùng
                sql = sql.TrimEnd(',');


                sql += " WHERE MaDoiNhom = @MaDoiNhom"; // Điều kiện WHERE


                using (SqlCommand command = new SqlCommand(sql, con))
                {
                    // Thêm các tham số
                    if (!string.IsNullOrEmpty(textBox_VaiTro.Text))
                    {
                        command.Parameters.AddWithValue("@VaiTro", textBox_VaiTro.Text);
                    }
                    if (!string.IsNullOrEmpty(textBox_MaSinhVien.Text))
                    {
                        command.Parameters.AddWithValue("@MaSinhVien", textBox_MaSinhVien.Text);
                    }
                    if (!string.IsNullOrEmpty(textBox_MaGiangVien.Text))
                    {
                        command.Parameters.AddWithValue("@MaGiangVien", textBox_MaGiangVien.Text);
                    }

                    command.Parameters.AddWithValue("@MaDoiNhom", textBox_MaDoiNhom.Text);//hóa chính để xác định dòng cần sửa


                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Cập nhật thành công!");
                        load();
                    }
                    else
                    {
                        MessageBox.Show("Không tìm thấy dữ liệu để cập nhật.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }

        }

        private void button_Xoa_Click_1(object sender, EventArgs e)
        {
            using (SqlConnection connection = Connection.GetSqlConnection())
            {
                try
                {
                    connection.Open();
                    string sql = "DELETE FROM ThanhVienDoiNhom WHERE MaDoiNhom = @MaDoiNhom";

                    // Thêm điều kiện cho MaSinhVien hoặc MaGiangVien nếu cần
                    if (!string.IsNullOrEmpty(textBox_MaSinhVien.Text))
                    {
                        sql += " AND MaSinhVien = @MaSinhVien";
                    }
                    if (!string.IsNullOrEmpty(textBox_MaGiangVien.Text))
                    {
                        sql += " AND MaGiangVien = @MaGiangVien";
                    }


                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@MaDoiNhom", textBox_MaDoiNhom.Text);

                        if (!string.IsNullOrEmpty(textBox_MaSinhVien.Text))
                        {
                            command.Parameters.AddWithValue("@MaSinhVien", textBox_MaSinhVien.Text);
                        }
                        if (!string.IsNullOrEmpty(textBox_MaGiangVien.Text))
                        {
                            command.Parameters.AddWithValue("@MaGiangVien", textBox_MaGiangVien.Text);
                        }

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Xóa thành công!");
                            load(); // Refresh dữ liệu sau khi xóa
                        }
                        else
                        {
                            MessageBox.Show("Không tìm thấy dữ liệu để xóa.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message);
                }
            }
        }

        private void button_Reset_Click(object sender, EventArgs e)
        {
            textBox_MaDoiNhom.ResetText();
            textBox_Id.ResetText();
            textBox_MaSinhVien.ResetText();
            textBox_MaGiangVien.ResetText();
            textBox_VaiTro.ResetText();
            load();
        }

        private void button_TimKiem_Click_1(object sender, EventArgs e)
        {
            DataTable dt = Red("SELECT * FROM ThanhVienDoiNhom  WHERE Id = '" + textBox_TenTimKiem.Text + "' ");
            if (dt != null)
            {
                dataGridView1.DataSource = dt;
            }
        }



        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox_Id.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            textBox_MaDoiNhom.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            textBox_MaSinhVien.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            textBox_MaGiangVien.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            textBox_VaiTro.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
        }
    }
}
