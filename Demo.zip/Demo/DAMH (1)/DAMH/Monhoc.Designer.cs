﻿namespace DAMH
{
    partial class Monhoc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            groupBox1 = new GroupBox();
            button_Reset = new Button();
            button_Xoa = new Button();
            button_Sua = new Button();
            button_Them = new Button();
            textBox_TenMonHoc = new TextBox();
            textBox_MaMonHoc = new TextBox();
            label3 = new Label();
            label2 = new Label();
            textBox_TenTimKiem = new TextBox();
            groupBox2 = new GroupBox();
            button_TimKiem = new Button();
            label6 = new Label();
            dataGridView1 = new DataGridView();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.HotTrack;
            label1.Location = new Point(343, 16);
            label1.Name = "label1";
            label1.Size = new Size(102, 26);
            label1.TabIndex = 8;
            label1.Text = "Môn học";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(button_Reset);
            groupBox1.Controls.Add(button_Xoa);
            groupBox1.Controls.Add(button_Sua);
            groupBox1.Controls.Add(button_Them);
            groupBox1.Controls.Add(textBox_TenMonHoc);
            groupBox1.Controls.Add(textBox_MaMonHoc);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Font = new Font("Segoe UI", 12.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(3, 185);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(395, 336);
            groupBox1.TabIndex = 10;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thông tin";
            // 
            // button_Reset
            // 
            button_Reset.BackColor = Color.LightGray;
            button_Reset.Font = new Font("Times New Roman", 12.75F);
            button_Reset.ForeColor = Color.Black;
            button_Reset.Location = new Point(305, 215);
            button_Reset.Name = "button_Reset";
            button_Reset.Size = new Size(75, 29);
            button_Reset.TabIndex = 15;
            button_Reset.Text = "Reset";
            button_Reset.UseVisualStyleBackColor = false;
            button_Reset.Click += button_Reset_Click;
            // 
            // button_Xoa
            // 
            button_Xoa.BackColor = Color.Red;
            button_Xoa.Font = new Font("Times New Roman", 12.75F);
            button_Xoa.ForeColor = Color.Transparent;
            button_Xoa.Location = new Point(305, 159);
            button_Xoa.Name = "button_Xoa";
            button_Xoa.Size = new Size(75, 29);
            button_Xoa.TabIndex = 14;
            button_Xoa.Text = "Xóa";
            button_Xoa.UseVisualStyleBackColor = false;
            button_Xoa.Click += button_Xoa_Click;
            // 
            // button_Sua
            // 
            button_Sua.BackColor = Color.DarkOrange;
            button_Sua.Font = new Font("Times New Roman", 12.75F);
            button_Sua.ForeColor = SystemColors.ButtonHighlight;
            button_Sua.Location = new Point(305, 95);
            button_Sua.Name = "button_Sua";
            button_Sua.Size = new Size(75, 29);
            button_Sua.TabIndex = 13;
            button_Sua.Text = "Sửa";
            button_Sua.UseVisualStyleBackColor = false;
            button_Sua.Click += button_Sua_Click;
            // 
            // button_Them
            // 
            button_Them.BackColor = Color.FromArgb(0, 192, 0);
            button_Them.Font = new Font("Times New Roman", 12.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button_Them.ForeColor = SystemColors.ButtonFace;
            button_Them.Location = new Point(305, 33);
            button_Them.Name = "button_Them";
            button_Them.Size = new Size(75, 29);
            button_Them.TabIndex = 12;
            button_Them.Text = "Thêm ";
            button_Them.UseVisualStyleBackColor = false;
            button_Them.Click += button_Them_Click;
            // 
            // textBox_TenMonHoc
            // 
            textBox_TenMonHoc.Location = new Point(124, 140);
            textBox_TenMonHoc.Name = "textBox_TenMonHoc";
            textBox_TenMonHoc.Size = new Size(147, 30);
            textBox_TenMonHoc.TabIndex = 9;
            // 
            // textBox_MaMonHoc
            // 
            textBox_MaMonHoc.Location = new Point(124, 94);
            textBox_MaMonHoc.Name = "textBox_MaMonHoc";
            textBox_MaMonHoc.Size = new Size(147, 30);
            textBox_MaMonHoc.TabIndex = 8;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 12F);
            label3.Location = new Point(20, 148);
            label3.Name = "label3";
            label3.Size = new Size(88, 19);
            label3.TabIndex = 5;
            label3.Text = "Tên môn học";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 12F);
            label2.Location = new Point(21, 102);
            label2.Name = "label2";
            label2.Size = new Size(86, 19);
            label2.TabIndex = 4;
            label2.Text = "Mã môn học";
            // 
            // textBox_TenTimKiem
            // 
            textBox_TenTimKiem.Font = new Font("Times New Roman", 12F);
            textBox_TenTimKiem.Location = new Point(135, 44);
            textBox_TenTimKiem.Name = "textBox_TenTimKiem";
            textBox_TenTimKiem.Size = new Size(185, 26);
            textBox_TenTimKiem.TabIndex = 16;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(button_TimKiem);
            groupBox2.Controls.Add(textBox_TenTimKiem);
            groupBox2.Controls.Add(label6);
            groupBox2.Font = new Font("Times New Roman", 12.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox2.Location = new Point(3, 78);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(843, 101);
            groupBox2.TabIndex = 11;
            groupBox2.TabStop = false;
            groupBox2.Text = "Tìm kiếm";
            // 
            // button_TimKiem
            // 
            button_TimKiem.BackColor = Color.LightGray;
            button_TimKiem.Font = new Font("Times New Roman", 12.75F);
            button_TimKiem.ForeColor = Color.Black;
            button_TimKiem.Location = new Point(340, 41);
            button_TimKiem.Name = "button_TimKiem";
            button_TimKiem.Size = new Size(108, 29);
            button_TimKiem.TabIndex = 16;
            button_TimKiem.Text = "Tìm kiếm";
            button_TimKiem.UseVisualStyleBackColor = false;
            button_TimKiem.Click += button_TimKiem_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 12F);
            label6.Location = new Point(32, 52);
            label6.Name = "label6";
            label6.Size = new Size(86, 19);
            label6.TabIndex = 15;
            label6.Text = "Mã môn học";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(432, 205);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(246, 177);
            dataGridView1.TabIndex = 9;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // Monhoc
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(848, 537);
            Controls.Add(label1);
            Controls.Add(groupBox1);
            Controls.Add(groupBox2);
            Controls.Add(dataGridView1);
            Name = "Monhoc";
            Text = "Monhoc";
            Load += Monhoc_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox textBox_TrangThai;
        private Label label8;
        private TextBox textBox_NgayKetThuc;
        private GroupBox groupBox1;
        private Label label7;
        private Button button_Reset;
        private Button button_Xoa;
        private Button button_Sua;
        private Button button_Them;
        private TextBox textBox_NgayBatDau;
        private TextBox textBox_MoTa;
        private TextBox textBox_TenDuAn;
        private TextBox textBox_MaDuAn;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private TextBox textBox_TenTimKiem;
        private GroupBox groupBox2;
        private Button button_TimKiem;
        private Label label6;
        private DataGridView dataGridView1;
        private TextBox textBox_TenMonHoc;
        private TextBox textBox_MaMonHoc;
    }
}