﻿namespace DAMH
{
    public partial class Dangnhap : Form
    {
        public Dangnhap()
        {
            InitializeComponent();
        }

        private void textBox_TenDangNhap_TextChanged(object sender, EventArgs e)
        {

        }

        private void linkLabel_QuenMK_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            QuenMK quenMK = new QuenMK();
            quenMK.ShowDialog();
        }

        private void linkLabel_DangKy_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Dangky dangky = new Dangky();
            dangky.ShowDialog();
        }
        Modify modify = new Modify();

        private void button_DangNhap_Click(object sender, EventArgs e)
        {
            string tendn = textBox_TenDangNhap.Text;
            string matkhau = textBox_MatKhau.Text;
            if (tendn.Trim() == " ") { MessageBox.Show("Vui lòng nhập tên tài khoản"); }
            else if (matkhau.Trim() == " ") { MessageBox.Show("Vui lòng nhập mật khẩu"); }
            else
            {
                string query = "select * from TaiKhoan where TenDangNhap = '" + tendn + "' and MatKhau = '" + matkhau + "'";
                if (modify.TaiKhoans(query).Count > 0)
                {
                    MessageBox.Show("Đăng nhập thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Hide();
                    Home2 home = new Home2();
                    home.ShowDialog();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Tên tài khoản hoặc mật khẩu không chính xác", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }

        }

        private void Dangnhap_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string tendn = textBox_TenDangNhap.Text;
            string matkhau = textBox_MatKhau.Text;
            if (tendn.Trim() == "")
            {
                MessageBox.Show("Vui lòng nhập tên tài khoản");
            }
            else if (matkhau.Trim() == "")
            {
                MessageBox.Show("Vui lòng nhập mật khẩu");
            }
            else if (tendn != "hungqtv" || matkhau != "2310") // Kiểm tra tên đăng nhập và mật khẩu
            {
                MessageBox.Show("Tên tài khoản hoặc mật khẩu không chính xác", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                // Thực hiện các hành động đăng nhập nếu tên đăng nhập và mật khẩu đúng
                MessageBox.Show("Đăng nhập thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Hide();
                Home home = new Home();
                home.ShowDialog();
                this.Close();
            }
        }
    }
}
