﻿namespace DAMH
{
    partial class Dangnhap
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dangnhap));
            textBox_TenDangNhap = new TextBox();
            label1 = new Label();
            linkLabel_DangKy = new LinkLabel();
            pictureBox1 = new PictureBox();
            label2 = new Label();
            linkLabel_QuenMK = new LinkLabel();
            textBox_MatKhau = new TextBox();
            button_DangNhap = new Button();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // textBox_TenDangNhap
            // 
            textBox_TenDangNhap.Location = new Point(163, 166);
            textBox_TenDangNhap.Name = "textBox_TenDangNhap";
            textBox_TenDangNhap.Size = new Size(128, 23);
            textBox_TenDangNhap.TabIndex = 0;
            textBox_TenDangNhap.TextChanged += textBox_TenDangNhap_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(68, 169);
            label1.Name = "label1";
            label1.Size = new Size(57, 15);
            label1.TabIndex = 1;
            label1.Text = "Tài khoản";
            // 
            // linkLabel_DangKy
            // 
            linkLabel_DangKy.AutoSize = true;
            linkLabel_DangKy.Location = new Point(241, 307);
            linkLabel_DangKy.Name = "linkLabel_DangKy";
            linkLabel_DangKy.Size = new Size(50, 15);
            linkLabel_DangKy.TabIndex = 2;
            linkLabel_DangKy.TabStop = true;
            linkLabel_DangKy.Text = "Đăng ký";
            linkLabel_DangKy.LinkClicked += linkLabel_DangKy_LinkClicked;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(90, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(180, 114);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(68, 206);
            label2.Name = "label2";
            label2.Size = new Size(57, 15);
            label2.TabIndex = 5;
            label2.Text = "Mật khẩu";
            // 
            // linkLabel_QuenMK
            // 
            linkLabel_QuenMK.AutoSize = true;
            linkLabel_QuenMK.Location = new Point(68, 307);
            linkLabel_QuenMK.Name = "linkLabel_QuenMK";
            linkLabel_QuenMK.Size = new Size(89, 15);
            linkLabel_QuenMK.TabIndex = 6;
            linkLabel_QuenMK.TabStop = true;
            linkLabel_QuenMK.Text = "Quên mật khẩu";
            linkLabel_QuenMK.LinkClicked += linkLabel_QuenMK_LinkClicked;
            // 
            // textBox_MatKhau
            // 
            textBox_MatKhau.Location = new Point(163, 198);
            textBox_MatKhau.Name = "textBox_MatKhau";
            textBox_MatKhau.PasswordChar = '*';
            textBox_MatKhau.Size = new Size(128, 23);
            textBox_MatKhau.TabIndex = 7;
            // 
            // button_DangNhap
            // 
            button_DangNhap.Location = new Point(216, 245);
            button_DangNhap.Name = "button_DangNhap";
            button_DangNhap.Size = new Size(75, 23);
            button_DangNhap.TabIndex = 8;
            button_DangNhap.Text = "Đăng nhập";
            button_DangNhap.UseVisualStyleBackColor = true;
            button_DangNhap.Click += button_DangNhap_Click;
            // 
            // button1
            // 
            button1.Location = new Point(135, 349);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 9;
            button1.Text = "Admin";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Dangnhap
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(357, 384);
            Controls.Add(button1);
            Controls.Add(button_DangNhap);
            Controls.Add(textBox_MatKhau);
            Controls.Add(linkLabel_QuenMK);
            Controls.Add(label2);
            Controls.Add(pictureBox1);
            Controls.Add(linkLabel_DangKy);
            Controls.Add(label1);
            Controls.Add(textBox_TenDangNhap);
            Name = "Dangnhap";
            Text = "Đăng nhập";
            Load += Dangnhap_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox_TenDangNhap;
        private Label label1;
        private LinkLabel linkLabel_DangKy;
        private PictureBox pictureBox1;
        private Label label2;
        private LinkLabel linkLabel_QuenMK;
        private TextBox textBox_MatKhau;
        private Button button_DangNhap;
        private Button button1;
    }
}
