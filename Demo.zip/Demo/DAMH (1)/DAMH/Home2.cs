﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAMH
{
    public partial class Home2 : Form
    {
        public Home2()
        {
            InitializeComponent();
        }
        private Form currentFormChild;
        private void OpenChildForm(Form childForm)
        {
            if (currentFormChild != null)
            {
                currentFormChild.Close();
            }
            currentFormChild = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panel_Body.Controls.Add(childForm);
            panel_Body.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();

        }


        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            OpenChildForm(new DoiNhom2());
            label1.Text = button9.Text;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Thanhviennhom2());
            label1.Text = button9.Text;
        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenChildForm(new MH2());
            label1.Text = button4.Text;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {


        }

        private void button_DangXuat_Click_1(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn đăng xuất không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult) ;
            {
                this.Hide();
                Dangnhap dangnhap = new Dangnhap();
                dangnhap.ShowDialog();
            }

            {

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            OpenChildForm(new GV2());
            label1.Text = button4.Text;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            OpenChildForm(new SV2());
            label1.Text = button4.Text;
        }

        private void panel_Top_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenChildForm(new DoiNhom2());
            label1.Text = button1.Text;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Duan2());
            label1.Text = button3.Text;
        }

        private void Home2_Load(object sender, EventArgs e)
        {

        }
    }
}
