﻿
CREATE TABLE TaiKhoan (
    TenDangNhap VARCHAR(50) PRIMARY KEY,
    MatKhau VARCHAR(255) NOT NULL,
    Email VARCHAR(255) NOT NULL  
);


CREATE TABLE NguoiDung (
    MaNguoiDung VARCHAR(20) PRIMARY KEY,
    HoTen NVARCHAR(100) NOT NULL,
    Email VARCHAR(100) UNIQUE,
    SoDienThoai VARCHAR(20),
    NgaySinh DATE,
    GioiTinh NVARCHAR(10),
    TenDangNhap VARCHAR(50) UNIQUE REFERENCES TaiKhoan(TenDangNhap)
);


CREATE TABLE SinhVien (
    MaSinhVien VARCHAR(20) PRIMARY KEY REFERENCES NguoiDung(MaNguoiDung),
    NganhHoc NVARCHAR(50)
);


CREATE TABLE GiangVien (
    MaGiangVien VARCHAR(20) PRIMARY KEY REFERENCES NguoiDung(MaNguoiDung),
    Khoa NVARCHAR(50)
);


CREATE TABLE DoiNhom (
    MaDoiNhom VARCHAR(20) PRIMARY KEY,
    TenDoiNhom NVARCHAR(100) NOT NULL,
    MoTa NVARCHAR(255),
    TrangThai BIT  
);



CREATE TABLE DuAn (
    MaDuAn VARCHAR(20) PRIMARY KEY,
    TenDuAn NVARCHAR(100) NOT NULL,
    MoTa NVARCHAR(255),
    NgayBatDau DATE,
    NgayKetThuc DATE,
    TrangThaiDuAn INT
);


CREATE TABLE KyNang (
    MaKyNang VARCHAR(20) PRIMARY KEY,
    TenKyNang NVARCHAR(100) NOT NULL,
    MoTa NVARCHAR(255)
);


CREATE TABLE MonHoc (
    MaMonHoc VARCHAR(20) PRIMARY KEY,
    TenMonHoc NVARCHAR(100) NOT NULL
);


CREATE TABLE TinNhan (
    MaTinNhan VARCHAR(20) PRIMARY KEY,
    NoiDung NVARCHAR(255) NOT NULL,
    ThoiGian DATETIME,
    DaXem BIT,
    NguoiGui VARCHAR(20) REFERENCES NguoiDung(MaNguoiDung),
    NguoiNhan VARCHAR(20) REFERENCES NguoiDung(MaNguoiDung)
);


CREATE TABLE ThongBao (
    MaThongBao VARCHAR(20) PRIMARY KEY,
    NoiDung NVARCHAR(255),
    ThoiGian DATETIME,
    DaXem BIT,
    MaNguoiNhan VARCHAR(20) REFERENCES NguoiDung(MaNguoiDung)
);


CREATE TABLE YeuCauThamGia (
    MaYeuCau VARCHAR(20) PRIMARY KEY,
    ThoiGian DATETIME,
    TrangThai INT,  -- Sử dụng số nguyên để biểu diễn enum
    MaSinhVien VARCHAR(20) REFERENCES SinhVien(MaSinhVien),
    MaDoiNhom VARCHAR(20) REFERENCES DoiNhom(MaDoiNhom)
);


CREATE TABLE NhanXetDanhGia (
    MaNhanXet VARCHAR(20) PRIMARY KEY,
    NoiDung NVARCHAR(255),
    DiemDanhGia FLOAT,
    ThoiGian DATETIME,
    MaNguoiDanhGia VARCHAR(20) REFERENCES NguoiDung(MaNguoiDung),  
    MaNguoiDuocDanhGia VARCHAR(20) REFERENCES NguoiDung(MaNguoiDung) 
);


CREATE TABLE KyNangDuAn (
    MaDuAn VARCHAR(20) REFERENCES DuAn(MaDuAn),
    MaKyNang VARCHAR(20) REFERENCES KyNang(MaKyNang),
    PRIMARY KEY (MaDuAn, MaKyNang)
);


CREATE TABLE ThanhVienDoiNhom (
    MaSinhVien VARCHAR(20) REFERENCES SinhVien(MaSinhVien),
    MaDoiNhom VARCHAR(20) REFERENCES DoiNhom(MaDoiNhom),
    VaiTro NVARCHAR(50),
    PRIMARY KEY (MaSinhVien, MaDoiNhom)
);


CREATE TABLE SinhVien_MonHoc (
    MaSinhVien VARCHAR(20) REFERENCES SinhVien(MaSinhVien),
    MaMonHoc VARCHAR(20) REFERENCES MonHoc(MaMonHoc),
    PRIMARY KEY (MaSinhVien, MaMonHoc)
);


CREATE TABLE GiangVien_MonHoc (
    MaGiangVien VARCHAR(20) REFERENCES GiangVien(MaGiangVien),
    MaMonHoc VARCHAR(20) REFERENCES MonHoc(MaMonHoc),
    PRIMARY KEY (MaGiangVien, MaMonHoc)
);